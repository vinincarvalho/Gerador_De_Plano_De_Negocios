const { DataTypes } = require('sequelize');
const sequelize = require('../config/database.js');
const Empresa = require('./company.js');

const RedeAtividades = sequelize.define('RedeAtividades', {
    id_rede_atividades: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    descricao: {
        type: DataTypes.TEXT,
        allowNull: false
    },
    atividade_principal: {
        type: DataTypes.TEXT,
        allowNull: false
    },
    atividades_auxiliares: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    responsaveis: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    id_empresa: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: Empresa,
            key: 'id_empresa'
        }
    }
});

Empresa.hasOne(RedeAtividades, { foreignKey: 'id_empresa' });
RedeAtividades.belongsTo(Empresa, { foreignKey: 'id_empresa' });

module.exports = RedeAtividades;
