const { DataTypes } = require('sequelize');
const sequelize = require('../config/database.js');
const Empresa = require('./company.js');

const PlanoOperacional = sequelize.define('PlanoOperacional', {
    id_plano_operacional: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    descricao_atividade: {
        type: DataTypes.TEXT,
        allowNull: false
    },
    equipamentos: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    pessoal_envolvido: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    localizacao: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    id_empresa: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: Empresa,
            key: 'id_empresa'
        }
    }
});

Empresa.hasOne(PlanoOperacional, { foreignKey: 'id_empresa' });
PlanoOperacional.belongsTo(Empresa, { foreignKey: 'id_empresa' });

module.exports = PlanoOperacional;
