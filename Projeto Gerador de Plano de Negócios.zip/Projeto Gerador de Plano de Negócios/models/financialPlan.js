const { DataTypes } = require('sequelize');
const sequelize = require('../config/database.js');
const Empresa = require('./company.js');

const PlanoFinanceiro = sequelize.define('PlanoFinanceiro', {
    id_plano_financeiro: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    investimento_inicial: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    custos_fixos: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    custos_variaveis: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    receitas_previstas: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    lucro_estimado: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    id_empresa: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: Empresa,
            key: 'id_empresa'
        }
    }
});

Empresa.hasOne(PlanoFinanceiro, { foreignKey: 'id_empresa' });
PlanoFinanceiro.belongsTo(Empresa, { foreignKey: 'id_empresa' });

module.exports = PlanoFinanceiro;
