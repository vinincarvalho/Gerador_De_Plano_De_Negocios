const { DataTypes } = require('sequelize');
const sequelize = require('../config/database.js');
const Empresa = require('./company.js');

const Despesa = sequelize.define('Despesa', {
    id_despesa: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    descricao: {
        type: DataTypes.TEXT,
        allowNull: false
    },
    valor: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false
    },
    data_vencimento: {
        type: DataTypes.DATE,
        allowNull: false
    },
    id_empresa: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: Empresa,
            key: 'id_empresa'
        }
    }
});

Empresa.hasMany(Despesa, { foreignKey: 'id_empresa' });
Despesa.belongsTo(Empresa, { foreignKey: 'id_empresa' });

module.exports = Despesa;
