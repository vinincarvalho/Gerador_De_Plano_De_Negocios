const { DataTypes } = require('sequelize');
const sequelize = require('../config/database.js');

const Empresa = sequelize.define('Empresa', {
    id_empresa: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    nome: {
        type: DataTypes.STRING(100),
        allowNull: false
    },
    cnpj: {
        type: DataTypes.STRING(14),
        allowNull: false,
        unique: true
    },
    missao: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    endereco: {
        type: DataTypes.STRING(200),
        allowNull: true
    },
    telefone: {
        type: DataTypes.STRING(20),
        allowNull: true
    }
});

module.exports = Empresa;
