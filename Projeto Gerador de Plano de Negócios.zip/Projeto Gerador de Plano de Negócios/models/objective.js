const { DataTypes } = require('sequelize');
const sequelize = require('../config/database.js');
const Empresa = require('./company.js');

const Objetivo = sequelize.define('Objetivo', {
    id_objetivo: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    descricao: {
        type: DataTypes.TEXT,
        allowNull: false
    },
    id_empresa: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: Empresa,
            key: 'id_empresa'
        }
    }
});

Empresa.hasMany(Objetivo, { foreignKey: 'id_empresa' });
Objetivo.belongsTo(Empresa, { foreignKey: 'id_empresa' });

module.exports = Objetivo;
