const express = require('express');
const router = express.Router();
const PDFDocument = require('pdfkit');
const Empresa = require('../models/company');
const Despesa = require('../models/expense');
const Objetivo = require('../models/objective');
const RedeAtividades = require('../models/activityNetwork');
const PlanoFinanceiro = require('../models/financialPlan');
const PlanoOperacional = require('../models/operationalPlan');
const Imposto = require('../models/tax');

// Exibir formulário para criar uma nova empresa
router.get('/new', (req, res) => {
    res.render('createCompany'); // Renderiza o formulário para criar empresa
});

// Criar uma nova empresa
router.post('/create', async (req, res) => {
    try {
        const empresa = await Empresa.create(req.body);
        res.redirect(`/companies/${empresa.id_empresa}/create-despesa`);
    } catch (error) {
        console.log(error);
        res.status(500).send("Erro ao criar empresa.");
    }
});

router.get('/edit/:id_empresa', async function(req, res){
    try {
        const company = await Empresa.findByPk(req.params.id_empresa);
        res.render('editCompany', { company })
    } catch(error) {
        console.log(error);
        res.status(500).send("Erro ao encontrar empresa.");
    }
});

router.post('/update/:id_empresa', async function(req, res){
    try {
        await Empresa.update(req.body, {
            where: { id_empresa: req.params.id_empresa }
        });
        res.redirect('/companies');
    } catch(error){
        console.log(error);
        res.status(500).send("Erro ao editar empresa.");
    }
});

// Exibir o formulário de criação de despesa
router.get('/:id_empresa/create-despesa', async (req, res) => {
    const { id_empresa } = req.params;
    res.render('createExpense', { id_empresa });
});

// Criar uma nova despesa
router.post('/:id_empresa/create-despesa', async (req, res) => {
    try {
        const { id_empresa } = req.params;
        await Despesa.create({ ...req.body, id_empresa });
        res.redirect(`/companies/${id_empresa}/create-plano-financeiro`);
    } catch (error) {
        console.log(error);
        res.status(500).send("Erro ao criar despesa.");
    }
});

// Exibir o formulário de criação de plano financeiro
router.get('/:id_empresa/create-plano-financeiro', async (req, res) => {
    const { id_empresa } = req.params;
    res.render('createFinancialPlan', { id_empresa });
});

// Criar um novo plano financeiro
router.post('/:id_empresa/create-plano-financeiro', async (req, res) => {
    try {
        const { id_empresa } = req.params;
        await PlanoFinanceiro.create({ ...req.body, id_empresa });
        res.redirect(`/companies/${id_empresa}/create-objetivo`);
    } catch (error) {
        console.log(error);
        res.status(500).send("Erro ao criar plano financeiro.");
    }
});

// Exibir o formulário de criação de objetivo
router.get('/:id_empresa/create-objetivo', async (req, res) => {
    const { id_empresa } = req.params;
    res.render('createObjective', { id_empresa });
});

// Criar um novo objetivo
router.post('/:id_empresa/create-objetivo', async (req, res) => {
    try {
        const { id_empresa } = req.params;
        await Objetivo.create({ ...req.body, id_empresa });
        res.redirect(`/companies/${id_empresa}/create-rede-atividades`);
    } catch (error) {
        console.log(error);
        res.status(500).send("Erro ao criar objetivo.");
    }
});

// Exibir o formulário de criação de rede de atividades
router.get('/:id_empresa/create-rede-atividades', async (req, res) => {
    const { id_empresa } = req.params;
    res.render('createActivityNetwork', { id_empresa });
});

// Criar uma nova rede de atividades
router.post('/:id_empresa/create-rede-atividades', async (req, res) => {
    try {
        const { id_empresa } = req.params;
        await RedeAtividades.create({ ...req.body, id_empresa });
        res.redirect(`/companies/${id_empresa}/create-plano-operacional`);
    } catch (error) {
        console.log(error);
        res.status(500).send("Erro ao criar rede de atividades.");
    }
});

// Exibir o formulário de criação de um plano de operação
router.get('/:id_empresa/create-plano-operacional', async (req, res) => {
    const { id_empresa } = req.params;
    res.render('createOperationalPlan', { id_empresa });
});

// Criar um novo plano de operação
router.post('/:id_empresa/create-plano-operacional', async (req, res) => {
    try {
        const { id_empresa } = req.params;
        await PlanoOperacional.create({ ...req.body, id_empresa });
        res.redirect(`/companies/${id_empresa}/create-imposto`);
    } catch (error) {
        console.log(error);
        res.status(500).send("Erro ao criar plano operacional");
    }
});

// Exibir o formulário de criação de um imposto
router.get('/:id_empresa/create-imposto', async (req, res) => {
    const { id_empresa } = req.params;
    res.render('createTax', { id_empresa });
});

// Criar um novo imposto
router.post('/:id_empresa/create-imposto', async (req, res) => {
    try {
        const { id_empresa } = req.params;
        console.log(req.body)
        await Imposto.create({ ...req.body, id_empresa });
        res.redirect(`/companies`);
    } catch (error) {
        console.log(error);
        res.status(500).send("Erro ao criar imposto.");
    }
});

// Rota para listar empresas
router.get('/', async function(req, res, next) {
    try {
        const companies = await Empresa.findAll();
        res.render('listCompany', { companies });
    } catch (error) {
        console.error('Erro ao buscar empresas:', error);
        next(error);
    }
});

// Excluir uma empresa
router.post('/delete/:id', async (req, res) => {
    try {
        await Empresa.destroy({ where: { id_empresa: req.params.id } });
        res.redirect('/companies');
    } catch (error) {
        res.status(500).send("Erro ao excluir empresa.");
    }
});

router.get('/generate-pdf/:id', async (req, res) => {
    try {
        // Buscar empresa e entidades relacionadas
        const company = await Empresa.findByPk(req.params.id, {
            include: [
                { model: Despesa },
                { model: Objetivo },
                { model: RedeAtividades },
                { model: PlanoFinanceiro },
                { model: PlanoOperacional },
                { model: Imposto }
            ]
        });

        if (!company) {
            return res.status(404).send('Empresa não encontrada');
        }

        // Criar o documento PDF
        const doc = new PDFDocument();

        // Configurar cabeçalho da resposta para o PDF
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename=${company.nome}.pdf`);

        // Pipe para enviar o PDF como resposta
        doc.pipe(res);

        // Adicionar informações principais da empresa
        doc.fontSize(18).text(`Informações da Empresa: ${company.nome}`, { align: 'center' });
        doc.moveDown();
        doc.fontSize(12).text(`CNPJ: ${company.cnpj}`);
        doc.text(`Missão: ${company.missao}`);
        doc.text(`Endereço: ${company.endereco}`);
        doc.text(`Telefone: ${company.telefone}`);
        doc.moveDown();

        // Adicionar despesas
        doc.fontSize(16).text('Despesas:', { underline: true });
        company.Despesas.forEach(despesa => {
            doc.fontSize(12).text(`Descrição: ${despesa.descricao}`);
            doc.text(`Valor: R$${despesa.valor}`);
            doc.text(`Data de Vencimento: ${despesa.data_vencimento}`);
            doc.moveDown();
        });

        // Adicionar objetivos
        doc.fontSize(16).text('Objetivos:', { underline: true });
        company.Objetivos.forEach(objetivo => {
            doc.fontSize(12).text(`Descrição: ${objetivo.descricao}`);
            doc.moveDown();
        });

        // Adicionar rede de atividades
        if (company.RedeAtividades) {
            doc.fontSize(16).text('Rede de Atividades:', { underline: true });
            doc.fontSize(12).text(`Descrição: ${company.RedeAtividades.descricao}`);
            doc.text(`Atividade Principal: ${company.RedeAtividades.atividade_principal}`);
            doc.text(`Atividades Auxiliares: ${company.RedeAtividades.atividades_auxiliares}`);
            doc.text(`Responsáveis: ${company.RedeAtividades.responsaveis}`);
            doc.moveDown();
        }

        // Adicionar plano financeiro
        if (company.PlanoFinanceiro) {
            doc.fontSize(16).text('Plano Financeiro:', { underline: true });
            doc.fontSize(12).text(`Investimento Inicial: R$${company.PlanoFinanceiro.investimento_inicial}`);
            doc.text(`Custos Fixos: R$${company.PlanoFinanceiro.custos_fixos}`);
            doc.text(`Custos Variáveis: R$${company.PlanoFinanceiro.custos_variaveis}`);
            doc.text(`Receitas Previstas: R$${company.PlanoFinanceiro.receitas_previstas}`);
            doc.text(`Lucro Estimado: R$${company.PlanoFinanceiro.lucro_estimado}`);
            doc.moveDown();
        }

        // Adicionar plano operacional
        if (company.PlanoOperacional) {
            doc.fontSize(16).text('Plano Operacional:', { underline: true });
            doc.fontSize(12).text(`Descrição da Atividade: ${company.PlanoOperacional.descricao_atividade}`);
            doc.text(`Equipamentos: ${company.PlanoOperacional.equipamentos}`);
            doc.text(`Pessoal Envolvido: ${company.PlanoOperacional.pessoal_envolvido}`);
            doc.text(`Localização: ${company.PlanoOperacional.localizacao}`);
            doc.moveDown();
        }

        // Adicionar impostos
        doc.fontSize(16).text('Impostos:', { underline: true });
        company.Impostos.forEach(imposto => {
            doc.fontSize(12).text(`Nome: ${imposto.nome}`);
            doc.text(`Percentual: ${imposto.percentual}%`);
            doc.moveDown();
        });

        // Finalizar o documento PDF
        doc.end();
    } catch (error) {
        console.error('Erro ao gerar PDF:', error);
        res.status(500).send('Erro ao gerar PDF');
    }
});

module.exports = router;
